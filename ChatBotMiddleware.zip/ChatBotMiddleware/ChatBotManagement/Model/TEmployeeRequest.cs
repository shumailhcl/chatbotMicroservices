﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChatBotManagement.Model
{
    public class TEmployeeRequest
    {
        [Key]
        public int requestId { get; set; }
        public int categoryId { get; set; }
        public int subCategoryId { get; set; }
        public int subCategoryChildId { get; set; }
        public string subCategoryChildOther { get; set; }
        public int employeeId { get; set; }   
        public int createdBy { get; set; }
        public int locationId { get; set; }
        public int needyUserId { get; set; }
    }
}
