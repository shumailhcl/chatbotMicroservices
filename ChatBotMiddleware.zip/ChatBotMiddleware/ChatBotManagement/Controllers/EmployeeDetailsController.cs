﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ChatBotManagement.Model;
using ChattbotManagment.Context;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using ChatBotManagement.BusinessLogicLayer;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ChatBotManagement.Controllers
{
   
    [ApiController]
    public class EmployeeDetailsController : ControllerBase
    {
        // GET: api/<EmployeeDetailsController>

        private ChatBotContext _chatbotContext;
        private IConfiguration _config;

        public EmployeeDetailsController (ChatBotContext chatbotContext, IConfiguration config)
        {
            _chatbotContext = chatbotContext;
            _config = config;
        }

       
        [HttpPost("getUserDetails")]
        public IActionResult Post([FromBody] mEmployeeDetails data)
        {

            try
            {
               
                if (data.employeeSapId!=0 && data.employeeEmailId?.ToString()!=null)
                {
                    var val = _chatbotContext.mEmployeeDetails.Where(x => (x.employeeEmailId == data.employeeEmailId && x.employeeSapId==data.employeeSapId && x.isActive == true));
                    if (val.Any())
                    {
                        var employeeDetails = val.SingleOrDefault();
                        Mail mail = new Mail();
                        mail.SendEmail(employeeDetails.employeeName, employeeDetails.employeeEmailId);
                        return Ok(employeeDetails);
                    }
                    else
                    {
                        return StatusCode(StatusCodes.Status401Unauthorized, new Error { error = "Invalid Sap or EmailId" });
                    }
                }
                else
                    return BadRequest(new Error { error = "SapId and EmailId Both are required" });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Error { error = ex.Message});
            }         
        }

        private string GenerateJSONWebToken()
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
              _config["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        [HttpPost("getLocation")]
       
        public ActionResult<mEmployeeDetails> Post([FromBody] int sapId)
        {
            try
            {            
                    var Detail = _chatbotContext.mEmployeeDetails.Join(_chatbotContext.mLocation,
                                  mEmployeeDetails => mEmployeeDetails.locationId,
                                  mLocation => mLocation.locationId,
                                  (mEmployeeDetails, mLocation) => new
                                  {
                                      employeeId = mEmployeeDetails.employeeId,
                                      employeeSapId = mEmployeeDetails.employeeSapId,
                                      employeeEmailId = mEmployeeDetails.employeeEmailId,
                                      locationId = mEmployeeDetails.locationId,
                                      locationName = mLocation.locationName,
                                      isActive = mEmployeeDetails.isActive
                                  }).Where(r => (r.isActive == true && r.employeeSapId == sapId));

                if (Detail.Any())
                {
                    return Ok(Detail.ToList());
                }
                else
                {
                    return BadRequest(new Error { error = "Invalid Sap Id" });
                }
 
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Error { error = ex.Message });
            }
        }

        [HttpPost("employeeRequest")]
        public ActionResult<TEmployeeRequest> EmployeeRequest([FromBody] TEmployeeRequest data)
        {
            try
            {
                if (data.employeeId != 0)
                {

                    _chatbotContext.tEmployeeRequest.Add(data);
                    var val = _chatbotContext.SaveChanges();                   
                    if (val == 1)
                    {
                        return Ok(val);
                    }
                    else
                    {
                        return StatusCode(StatusCodes.Status500InternalServerError, new Error { error = "Something Went Wrong" });
                    }
                }
                
                else
                    return BadRequest(new Error { error = "Employee Id is incorrect" });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Error { error = ex.Message });
            }
        }






    }
}
