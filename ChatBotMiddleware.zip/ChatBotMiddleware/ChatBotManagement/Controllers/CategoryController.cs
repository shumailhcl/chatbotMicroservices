﻿using ChatBotManagement.Model;
using ChattbotManagment.Context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ChatBotManagement.Controllers
{
   
    [ApiController]
    public class CategoryController : ControllerBase
    {
        // GET: api/<ChatBotController>
        ChatBotContext _chatbotContext;

        public CategoryController(ChatBotContext chatbotContext)
        {
            _chatbotContext = chatbotContext;
        }
        [HttpGet("getCategoryList")]
       
        public ActionResult<mCategory> Get()
        {
            try
            {
                
                return Ok(_chatbotContext.mCategory.Where(x=>x.isActive==true).ToList());
               
            }
            catch(Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,new Error { error = ex.Message });
            }
        }

        // GET api/<ChatBotController>/5
        [HttpGet("getSubCategory/{categoryId}")]

        public ActionResult<SubCategory> Get(int categoryId)
       {
            try
            {              
              var subCategory =_chatbotContext.mSubCategory.Where(x=>(x.categoryId== categoryId && x.isActive==true));
                if (subCategory.Any())
                    return Ok(subCategory.ToList());
                else
                return BadRequest(new Error { error = "CategoryId is invalid" });

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Error { error = ex.Message });
            }
        }

        [HttpGet("getSubCategoryChild{categoryId}/{subCategoryId}")]
        public ActionResult<SubCategoryChild> Get(int categoryId,int subCategoryId)
        {
            try
            {
                var subCategoryChild = _chatbotContext.mSubCategoryChild.Where(x => (x.subCategoryId==subCategoryId && x.categoryId == categoryId && x.isActive == true));
                if (subCategoryChild.Any())
                    return Ok(subCategoryChild.ToList());
                else
                    return BadRequest(new Error { error = "SubCategoryId is invalid" });

            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Error { error = ex.Message });
            }
        }



        [HttpGet("getNeedyUserType")]
        public ActionResult<mNeedyUser> GetNeedyUSeType()
        {
            try
            {
                return Ok(_chatbotContext.mNeedyUser.Where(x => x.isActive == true).ToList());
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Error { error = ex.Message });
            }
        }



        [HttpGet("getResponseType")]
        public ActionResult<mResponseType> GetResponseType()
        {
            try
            {
                return Ok(_chatbotContext.mResponseType.Where(x => x.isActive == true).ToList());
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new Error { error = ex.Message });
            }
        }
    }




}

