﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;

namespace ChatBotManagement.BusinessLogicLayer
{
    public class Mail
    {
        public void SendEmail(string employeeName,string employeeEmailId)
        {
            Random random = new Random();
            var activationCode = random.Next(100001, 999999).ToString();
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential("hcl.helpinghand@gmail.com", "Hcl@12345");
            smtp.EnableSsl = true;
            MailMessage msg = new MailMessage();
            msg.Subject = "Activation code to verify Email";
            msg.Body = "Dear " + employeeName + " Your activation Code is " + activationCode + "\n\n Thanks  \n IT Team";
            string toAddress = employeeEmailId;
            msg.To.Add(toAddress);
            string fromAddress = "IT Team <hcl.helpinghand@gmail.com>";
            msg.From = new MailAddress(fromAddress);
            smtp.Send(msg);
           
        }
    }
}
